package ai.evolution.gp;

import ai.core.AI;
import gui.PhysicalGameStateJFrame;
import gui.PhysicalGameStatePanel;
import rts.GameState;
import rts.PhysicalGameState;
import rts.PlayerAction;
import rts.units.Unit;
import rts.units.UnitTypeTable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class GPMatch {
    private GPMatch() {
    }

    public record EvaluationCase(int mapIndex, String opponentName) {
        public String describe(String[] mapPaths) {
            return opponentName + "@" + mapPaths[mapIndex];
        }
    }

    public record GameResult(double score, double margin, double gatheredShare, int cycles, boolean endedByLimit,
                             boolean crashed) {
    }

    public record MatchupResult(EvaluationCase evaluationCase, double score, double rawScore, double margin,
                                double asPlayer0, double asPlayer1, int limitedGames) {
    }

    public static List<MatchupResult> evaluate(GPIndividual individual, UnitTypeTable utt,
                                               List<PhysicalGameState> maps, List<EvaluationCase> cases,
                                               GPConfig cfg) throws Exception {
        List<MatchupResult> results = new ArrayList<>(cases.size());
        for (EvaluationCase c : cases) results.add(evaluateCase(individual, utt, maps, c, cfg));
        return results;
    }

    private static MatchupResult evaluateCase(GPIndividual individual, UnitTypeTable utt,
                                              List<PhysicalGameState> maps, EvaluationCase c,
                                              GPConfig cfg) throws Exception {
        PhysicalGameState map = maps.get(c.mapIndex());
        long seed = mixSeed(cfg.evaluationSeed, c.opponentName(), c.mapIndex());
        GameResult asP0 = playOneGame(new GPTreeAI(utt, individual.root),
                GPOpponents.build(c.opponentName(), utt, seed), map, utt, cfg, 0, false);
        GameResult asP1 = playOneGame(GPOpponents.build(c.opponentName(), utt, seed ^ 0x9E3779B97F4A7C15L),
                new GPTreeAI(utt, individual.root), map, utt, cfg, 1, false);
        return new MatchupResult(c,
                (shapedScore(asP0, cfg) + shapedScore(asP1, cfg)) / 2,
                (asP0.score() + asP1.score()) / 2,
                (asP0.margin() + asP1.margin()) / 2,
                asP0.score(), asP1.score(),
                (asP0.endedByLimit() ? 1 : 0) + (asP1.endedByLimit() ? 1 : 0));
    }

    static double shapedScore(GameResult r, GPConfig cfg) {
        if (r.crashed()) return 0.0;
        if (r.score() == 1.0) return 1.0;
        if (r.score() == 0.0) return cfg.lossMarginWeight * ((1 + r.margin()) / 2 + r.gatheredShare()) / 2;
        if (r.endedByLimit()) return Math.clamp(0.5 + cfg.drawMarginWeight * r.margin(), 0, 1);
        return 0.5;
    }

    public static GameResult playOneGame(AI ai1, AI ai2, PhysicalGameState map, UnitTypeTable utt,
                                         GPConfig cfg, int candidatePlayer, boolean visualize) throws Exception {
        ai1.reset(utt);
        ai2.reset(utt);
        GameState gs = new GameState(map.clone(), utt);
        PhysicalGameStateJFrame window = visualize ? PhysicalGameStatePanel.newVisualizer(gs, 600, 600, false) : null;
        int lastActionTime = 0;
        boolean gameover;
        Tally tally = new Tally(gs);
        try {
            do {
                PlayerAction pa1, pa2;
                try {
                    pa1 = ai1.getAction(0, gs);
                    pa2 = ai2.getAction(1, gs);
                } catch (RuntimeException e) {
                    reportCrash(ai1, ai2, gs, e);
                    return new GameResult(0.0, 0.0, 0.0, gs.getTime(), false, true);
                }
                if (gs.issueSafe(pa1)) lastActionTime = gs.getTime();
                if (gs.issueSafe(pa2)) lastActionTime = gs.getTime();
                gameover = gs.cycle();
                tally.update(gs);
                if (window != null) {
                    window.setStateCloning(gs);
                    window.repaint();
                    Thread.sleep(Math.max(0, cfg.playVisualDelayMillis));
                }
            } while (!gameover && gs.getTime() < cfg.maxCycles
                    && gs.getTime() - lastActionTime < cfg.maxInactiveCycles);
        } finally {
            if (window != null) window.dispose();
        }
        int winner = gs.winner();
        ai1.gameOver(winner);
        ai2.gameOver(winner);
        double score = winner == -1 ? 0.5 : winner == candidatePlayer ? 1.0 : 0.0;
        return new GameResult(score, tally.exchangeMargin(candidatePlayer), tally.gatheredShare(candidatePlayer),
                gs.getTime(), !gameover, false);
    }

    private static final Set<String> reportedCrashes = ConcurrentHashMap.newKeySet();

    private static void reportCrash(AI ai1, AI ai2, GameState gs, RuntimeException e) {
        StackTraceElement origin = e.getStackTrace().length > 0 ? e.getStackTrace()[0] : null;
        String signature = ai1.getClass().getSimpleName() + " vs " + ai2.getClass().getSimpleName()
                + " | " + e.getClass().getName() + " @ " + origin;
        if (!reportedCrashes.add(signature)) return;
        System.out.println("WARNING: bot threw at cycle " + gs.getTime() + " (" + signature
                + "); scored as a loss for the candidate. Identical failures are silent from now on.");
        e.printStackTrace(System.out);
    }

    /**
     * Tracks the cost of every unit each player has had destroyed, and the resources each player's workers
     * delivered. The end-of-game material count cannot rank losses, because the loser has no units left: it
     * only measures unspent resources. Losses that trade evenly still differ in how much the loser mined.
     */
    private static final class Tally {
        private final double[] lost = new double[2];
        private final double[] gathered = new double[2];
        private Map<Long, Unit> alive = new HashMap<>();
        private Map<Long, Integer> carried = new HashMap<>();

        Tally(GameState gs) {
            update(gs);
        }

        void update(GameState gs) {
            Map<Long, Unit> now = new HashMap<>();
            Map<Long, Integer> carrying = new HashMap<>();
            for (Unit u : gs.getPhysicalGameState().getUnits()) {
                if (u.getPlayer() < 0) continue;
                now.put(u.getID(), u);
                if (u.getType().canHarvest) carrying.put(u.getID(), u.getResources());
            }
            for (Map.Entry<Long, Unit> e : alive.entrySet()) {
                if (!now.containsKey(e.getKey())) lost[e.getValue().getPlayer()] += e.getValue().getType().cost;
            }
            // A worker that was carrying and now carries nothing, while still alive, has delivered its load.
            for (Map.Entry<Long, Integer> e : carrying.entrySet()) {
                int before = carried.getOrDefault(e.getKey(), 0);
                if (before > 0 && e.getValue() == 0) gathered[now.get(e.getKey()).getPlayer()] += before;
            }
            alive = now;
            carried = carrying;
        }

        /** The candidate's share of all resources delivered; 0.5 when neither side mined. */
        double gatheredShare(int candidatePlayer) {
            double total = gathered[0] + gathered[1];
            return total == 0 ? 0.5 : gathered[candidatePlayer] / total;
        }

        /** -1 when only the candidate lost units, +1 when only the opponent did, 0 for an even trade or no fighting. */
        double exchangeMargin(int candidatePlayer) {
            double killed = lost[1 - candidatePlayer];
            double suffered = lost[candidatePlayer];
            return (killed - suffered) / (killed + suffered + 1e-6);
        }
    }

    private static long mixSeed(long seed, String opponentName, int mapIndex) {
        long x = seed ^ ((long) opponentName.hashCode() << 32) ^ mapIndex;
        x ^= (x >>> 33);
        x *= 0xff51afd7ed558ccdL;
        x ^= (x >>> 33);
        return x;
    }
}
